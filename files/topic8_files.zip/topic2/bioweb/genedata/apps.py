from django.apps import AppConfig


class GenedataConfig(AppConfig):
    name = 'genedata'
